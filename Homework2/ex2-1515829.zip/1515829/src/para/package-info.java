/**
 * 演習のプログラム用パッケージ
 */
package para;
