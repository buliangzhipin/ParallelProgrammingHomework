package para;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Test {
	public static void main(String[] args) {
//		File file = new File("1.jpg");
//		File file2 = new File("2.jpg");
//		
//		try(OutputStream out = new FileOutputStream(file2);InputStream rd = new FileInputStream(file)) {
//			BufferedInputStream bin = new BufferedInputStream(rd);
//			BufferedOutputStream bout = new BufferedOutputStream(out);
//			
//			byte[] b = new byte[1024];
//			while(bin.read(b)!=-1) {
//				bout.write(b);
//			}
//			bin.close();
//			bout.close();
//			System.out.println("finished");
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e1) {
//			e1.printStackTrace();
//		}
		

	}
}
