/**
 * web camera の起動、終了、撮影するためにJavaCVとの橋渡しをするクラスをまとめたパッケージ
 */
package para.graphic.camera;
